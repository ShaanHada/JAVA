package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cybage.Account;
import com.cybage.AccountException;
import com.cybage.dbutil.DbUtil;

public class AccountDaoImpl implements AccountDao{

	@Override
	public String addAccount(Account account) throws Exception {
		String sql = "insert into account values(?, ?, ?, ?)";
		Connection con = DbUtil.getConnection();		//new object
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, account.getAccNumber());
		ps.setString(2, account.getAccType());
		ps.setString(3, account.getCustId());
		ps.setDouble(4, account.getBalance());

		if(ps.executeUpdate() == 1) {
			con.commit();			//customer + account will be committed
			ps.close(); 
			con.close();  
			return account.getAccNumber();
		}
		else{ 
			con.rollback();
			ps.close(); 
			con.close(); 
			return null;
		}
	}

	@Override
	public double getBalance(String accNumber) throws AccountException, Exception {
		String sql = "select balance from account where accnumber = ?";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, accNumber);
		ResultSet rs= ps.executeQuery();
		if(rs.next()){
			double temp = rs.getDouble(1);
			rs.close();
			ps.close();			
			con.close();
			return temp;
		}else{
			rs.close();
			ps.close();			
			con.close();
			throw new AccountException("account doesnot exists...");
		}
	}
	
	public List<Account> getAccount() throws Exception{
		List<Account> accountList = new ArrayList<>();
		String sql = "select * from account";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs= ps.executeQuery();
		while(rs.next()){
			Account account = new Account(rs.getString("accNumber"), rs.getString("accType"), rs.getString("idcust"), rs.getDouble("balance"));
			accountList.add(account);
			
			
		}
		rs.close();
		ps.close();			
		con.close();
		return accountList;
	}
	
	
}
