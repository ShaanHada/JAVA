package com.cybage.dao;

import com.cybage.Customer;

public interface ICustomerDao {
	public String addCustomer(Customer c1) throws Exception;

}
