package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cybage.Customer;
import com.cybage.dbutil.DbUtil;

public class CustomerDaoImpl implements ICustomerDao{
	
	

	@Override
	public String addCustomer(Customer c1) throws Exception {
		
			
				//store customer in database
				
				String sql = "insert into customer values(?, ?, ?)";
				Connection con = DbUtil.getConnection();			//new object
				con.setAutoCommit(false);
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, c1.getCustId());
				ps.setString(2, c1.getCustName());
				ps.setString(3, c1.getCustAddress());
				
				if(ps.executeUpdate() == 1) {
					con.commit();			//customer + account will be committed
					ps.close(); 
					con.close();  
					return c1.getCustId();
				}
				else{ 
					con.rollback();
					ps.close(); 
					con.close(); 
					return null;
				}
	}
	
	

}
