package com.cybage;

public class SavingAccount extends Account{

	public SavingAccount() {
		super();
	}

	public SavingAccount(String accNumber, String accType, String custId, double balance) {
		super(accNumber, accType, custId, balance);
	}

}
