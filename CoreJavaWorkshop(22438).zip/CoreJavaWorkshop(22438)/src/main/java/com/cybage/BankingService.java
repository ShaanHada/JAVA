package com.cybage;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cybage.dao.AccountDao;
import com.cybage.dao.AccountDaoImpl;
import com.cybage.dao.CustomerDaoImpl;
import com.cybage.dao.ICustomerDao;

//this class is specific certain project
public class BankingService implements Banking{

	CustomerService cs = new CustomerService();
	ICustomerDao cust = new CustomerDaoImpl();
	AccountDao dao = new AccountDaoImpl();
	public static final Logger logger = LogManager.getLogger(BankingService.class.getName());
	
	private String generateAccNumber(){
		return "H"+ Math.round(Math.random()*99999);
	}
	@Override
	public String openAccount(String accType,
			String name, 
			String address, 
			double balance) throws AccountException, Exception
	{		
		if(balance < 10000){
			throw new AccountException("Cannot create account as amount is less than 10000");
		}
		Customer c1 = cs.addCustomer(name, address);
		String custId = cust.addCustomer(c1);
			
		//need to create account and store in database
		Account account = null;
		switch (accType) {
		case "SAVING":	
			account = new SavingAccount(generateAccNumber(), accType, custId, balance);
			break;
		case "CURRENT":
			account = new CurrentAccount(generateAccNumber(), accType, custId, balance);
			break;
		default: 
			account = null;
		}
		
		String createdAccount = dao.addAccount(account);
		logger.info("Account created with account number: "+ createdAccount);
		return createdAccount;
	}
	@Override
	public double getBalance(String accNumber) throws AccountException, Exception{
		///adding blanace in logger but not recommended..
		double balance = dao.getBalance(accNumber);
		logger.info("Account created with account number: "+  balance);
		return balance;		
	}
	
	@Override
	public double withdrawl(String accNumber, double amount)  {
		double availableBalance  = 0;
		double tempBalance = 0;
		boolean found = false;
		List<Account> accounts;
		try {
			accounts = dao.getAccount();
			for(Account account: accounts){
				if(account.getAccNumber().equals(accNumber)){
					availableBalance = account.getBalance();
					tempBalance = availableBalance - amount;
					if(tempBalance < 10000){
						throw new AccountException("Cannot withdrawl as effective balance goes below 10000");
					}else{
						account.setBalance(tempBalance);
					}
					found = true;
					logger.info("Amount Debited, Remaining Balance: "+ account.getBalance());
					break;
				}
			}
			if(found) return tempBalance;
			else {
				throw new AccountException("Account does not exists");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return tempBalance;
		
		
	}
	
	public List<Account> listAccount() throws  Exception{
		List<Account> accounts = dao.getAccount();
		return accounts;
	}
	
	public double getInterest(String accNumber) throws  Exception{
		List<Account> accounts = dao.getAccount();
		double si=0;
		boolean found = false;
			for(Account account: accounts){
				if(account.getAccNumber().equals(accNumber))	
			si=account.getBalance()*roi/100;	
				found = true;
				break;
	} 
			if(found) return si;
			else {
		throw new AccountException("Account does not exists");
	}
			
			
			}
	
}