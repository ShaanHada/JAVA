package com.cybage;

import java.util.List;

public class UI {
	public static void main(String[] args) throws Exception{
		System.out.println("Welcome to HDFC bank");

		BankingService bs = new BankingService();
		//value will come from html page from user
		bs.openAccount(AccountType.CURRENT.toString(), "dm102", "pune123", 40000);

		//getting balance
//		System.out.println("avaliable balance: " + bs.getBalance("H57770"));	
		double balance = bs.withdrawl( "H71729", 10000) ;
		System.out.println("Balance after withdrawl "+balance);
		
		//listing account
		List<Account> account= bs.listAccount();
		
		account.parallelStream().forEach(System.out::println);
		
		// interest
		double si = bs.getInterest("H10319");
		System.out.println("rate of interest is "+ si);
	}
}