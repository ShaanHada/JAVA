package com.cybage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomerService implements iCustomer{

	private String generateCustID(){
		return "C"+ Math.round(Math.random()*999999999);
	}
	public static final Logger logger = LogManager.getLogger(BankingService.class.getName());
	
	@Override
	public Customer addCustomer(String name, String address) {	
		Customer c =  new Customer(generateCustID(), name, address);
		logger.info("Account created with account number: "+ generateCustID());
		return c;
	}	
}
