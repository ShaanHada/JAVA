import java.sql.*;
public class DemoInsert {

	public static void main(String[] args) throws Exception {
		String url="jdbc:mysql://localhost:3306/MYDB";
		String uname="root";
		String pwd= "root123$";
		int sid= 104;
		String sname="Alia";
//		String query="insert into student values(105,'Mona')";
//		String query="insert into student values(" +sid+ ",'" +sname+ "')";
		String query="insert into student values(?,?)";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con= DriverManager.getConnection(url,uname,pwd);
		PreparedStatement st=con.prepareStatement(query);
		st.setInt(1,sid);
		st.setString(2,sname);
		int count=st.executeUpdate();
		System.out.println(count +" Row/s affected");
	}
}
