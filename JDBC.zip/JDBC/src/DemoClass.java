import java.sql.*;
public class DemoClass {

	public static void main(String[] args) throws Exception {
		String url="jdbc:mysql://localhost:3306/MYDB";
		String uname="root";
		String pwd= "root123$";
		String query= "select * from student";
//		String query= "delete from student where name='Alia'";
//		String query= "select name from student where stuId=103";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,uname,pwd);
		Statement st= con.createStatement();
//		int count=st.executeUpdate(query);
		ResultSet rs= st.executeQuery(query);
		while(rs.next())
		{
			String StudentData=rs.getInt("stuId")+" "+rs.getString("name");
		String name=rs.getString("name");
			System.out.println(StudentData);
		}
	}
}
