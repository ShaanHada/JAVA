package DAODemo;

import java.sql.*;

public class StudentDAO {
	Connection con=null;
	public void connect() throws Exception
	{
		String url="jdbc:mysql://localhost:3306/MYDB";
		String uname="root";
		String pwd= "root123$";
		Class.forName("com.mysql.cj.jdbc.Driver");
		con= DriverManager.getConnection(url,uname,pwd);
	}
	public Student getName(int sid) throws Exception
	{
//		String url="jdbc:mysql://localhost:3306/MYDB";
//		String uname="root";
//		String pwd= "root123$";
		String query= "select name from student where stuId= "+sid;
//		Class.forName("com.mysql.cj.jdbc.Driver");
//		Connection con= DriverManager.getConnection(url,uname,pwd);
		Statement st= con.createStatement();
		ResultSet rs= st.executeQuery(query);
		Student s= new Student();
		rs.next(); 
		String sname=rs.getString(1);
		s.name=sname;
		return s;
	}

	public void addStudent(Student s2) throws Exception {
		String query= "insert into student values(?,?)";
		PreparedStatement pst =con.prepareStatement(query);
		pst.setInt(1,105);
		pst.setString(2,"Kriti");
		pst.executeUpdate();
	}

	public void removeStudent(String sname) throws Exception {
//		String query="delete from student where name= " +"'" +sname +"'";
//		Statement st= con.createStatement();
		String query="delete from student where name= ?";
		PreparedStatement pst =con.prepareStatement(query);
		pst.setString(1,"Alia");
		int count= pst.executeUpdate();
		System.out.println(count +" Row/s affected");
	}
}
