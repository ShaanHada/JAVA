package DAODemo;

public class DAODemo1 {

	public static void main(String[] args) throws Exception  {
		StudentDAO dao=new StudentDAO();
		dao.connect();
		Student s1= dao.getName(106);
		System.out.println(s1.name );
	}
}
