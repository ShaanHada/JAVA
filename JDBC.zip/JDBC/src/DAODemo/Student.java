package DAODemo;

public class Student {
		int sid;
		String name;
}
