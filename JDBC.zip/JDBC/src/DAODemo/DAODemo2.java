package DAODemo;

public class DAODemo2 {

	public static void main(String[] args) throws Exception {
		StudentDAO dao=new StudentDAO();
//		Student s2= new Student();
//		s2.name= "Alia";
		dao.connect();
		dao.removeStudent("Alia");
	}
}
