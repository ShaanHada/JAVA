package Fourth;

import java.util.ArrayList;
import java.util.Scanner;

public class BreakInteger {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a no: ");
		int num = sc.nextInt();
		ArrayList<Integer> emp = new ArrayList<>();
		while(num >0) {
		int temp = num%10;
		emp.add(temp);
		num= num/10;
		}
//		for(int arr:emp)
		for(int i=emp.size()-1;i>=0; i--)
		{
			System.out.print(emp.get(i)+ " ");
		}
	}

}
