package Second;

public class UI {

	public static void main(String[] args) {
		
//		Object using Non_parameterized Constructor 
		Date d1 = new Date();
		d1.setDay(04);
		d1.setMonth("January");
		d1.setYear(1996);
		
		System.out.print("Date1: "+d1.getDay());
		System.out.print("-"+d1.getMonth());
		System.out.println("-"+d1.getYear());
		
//		Object using Parameterized Constructor
		Date d2 = new Date(12,"February",1994);
		System.out.println("Date2: "+d2.toString());

	}

}
