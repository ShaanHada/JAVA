package Fifth;

import java.util.Scanner;

public class UI {

	public static void main(String[] args) {
		System.out.println("Enter an String: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		MiddleString m = new MiddleString();
		m.middle(s);

	}
}
