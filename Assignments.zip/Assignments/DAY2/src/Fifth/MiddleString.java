package Fifth;

import java.util.Scanner;

public class MiddleString {

	public void middle(String s) {
		String s1 = "";
		int l = s.length();
		if(l%2==0)
		{
			 s1 = "Middle Characters: "+s.charAt((l/2)-1) + " & " + s.charAt((l/2) );
		}
		else {
			 s1 = "Middle Character: "+s.charAt((l/2));
		}
		System.out.println(s1);
	}
}
