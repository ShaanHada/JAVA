package Third;

import java.util.Scanner;

public class AddDigit {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number between 0 and 1000");
		int num = sc.nextInt();
		
		int firstdigit= num%10;
		int remainingno= num/10;
		int seconddigit = remainingno%10;
		remainingno = remainingno/10;
		int thirddigit = remainingno%10;
		
		int sum = thirddigit + seconddigit + firstdigit;
		System.out.println("Sum of all digits: " +sum);
		
	}
}
