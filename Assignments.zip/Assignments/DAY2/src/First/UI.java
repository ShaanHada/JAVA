package First;

public class UI {

	public static void main(String[] args) {
		Employee e1 = new Employee();
		 e1.setId("E101");
		 e1.setName("Mukesh");
		 e1.setAddress("Pune");
		 e1.setMob_No(9355262523L);
		 
		 System.out.println("EmpId: " +e1.getId());
		 System.out.println("Name: "+e1.getName());
		 System.out.println("Address: "+e1.getAddress());
		 System.out.println("Mob_No: " +e1.getMob_No());
	}

}
