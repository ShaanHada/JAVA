package First;

public class Employee {
	private String Id;
	private String Name;
	private String Address;
	private Long Mob_No;
	
	public Employee() {
		super();
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public Long getMob_No() {
		return Mob_No;
	}

	public void setMob_No(Long mob_No) {
		Mob_No = mob_No;
	}

	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Address=" + Address + ", Mob_No=" + Mob_No + "]";
	}

	
	
}
