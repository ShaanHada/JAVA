package Fourth;

public class Insert {

}
