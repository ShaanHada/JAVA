package Fourth;

import java.util.Arrays;

public class UI {

	public static void main(String[] args) {
		int n=10;
		int i;
		
		// initial array of size 10 
		int arr[] = {12,24,45,76,98,35,68,79,56,23};
		
		System.out.println("Initial Array: "+Arrays.toString(arr));
		 int x = 50;
		 int pos = 5;
		 
//		 InsertArray ia = new InsertArray();
		 arr = InsertArray.Insert(n,arr,x,pos);
		 
//		 print the updated array 
	        System.out.println("\nArray after inserting " + x + " at position "+ pos + ":\n"
	                           + Arrays.toString(arr));
	}
}
