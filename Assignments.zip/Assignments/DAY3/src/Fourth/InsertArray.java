package Fourth;

public class InsertArray {
	public static int[] Insert(int n,int arr[], int x, int pos) {
		int i;
		
		//create a new aaray of size n+1
		int newarr[] = new  int[n+1];
		
		// insert the elements from the old array into the new array
        // insert all elements till pos then insert x at pos 
		//then insert rest of the elements 
		for (i = 0; i < n + 1; i++) { 
            if (i < pos - 1) 
                newarr[i] = arr[i]; 
            else if (i == pos - 1) 
                newarr[i] = x; 
            else
                newarr[i] = arr[i - 1]; 
        } 
        return newarr; 
		
	} 
}