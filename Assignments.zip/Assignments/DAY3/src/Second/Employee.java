package Second;

import java.util.ArrayList;
import java.util.List;

public class Employee {
	private String  id;
	private String name;
	private String Address;
	private long Mob_No;
	
	
	
	public Employee(String id, String name, String address, long mob_No) {
		super();
		this.id = id;
		this.name = name;
		Address = address;
		Mob_No = mob_No;
	}



	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", Address=" + Address + ", Mob_No=" + Mob_No + "]";
	}
}
