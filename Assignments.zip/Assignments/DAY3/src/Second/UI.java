package Second;

import java.util.ArrayList;
import java.util.List;

public class UI {

	public static void main(String[] args) {
		List<Employee> emp = new ArrayList<>();
		emp.add(new Employee("E101", "Mahesh", "Pune", 9394634906L));
		emp.add(new Employee("E102", "Mukesh", "Mumbai",9439463490L));
		emp.add(new Employee("E103", "Rajesh", "Delhi", 9694634906L));
		
		for(Employee e:emp)
		System.out.println(e.toString());

	}
}
