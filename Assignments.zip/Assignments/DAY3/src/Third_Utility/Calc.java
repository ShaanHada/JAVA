package Third_Utility;

public class Calc {
	public int findRoot(int n) {
		
		if (n == 0 || n == 1) 
            return n; 
  
        // Staring from 1, try all numbers until 
        // i*i is greater than or equal to n. 
        int i = 1, result = 1; 
          
        while (result <= n) { 
            i++; 
            result = i * i; 
        } 
        return i - 1; 
		
	}
}
