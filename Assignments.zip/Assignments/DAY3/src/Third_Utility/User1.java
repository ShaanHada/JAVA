package Third_Utility;

import java.util.Scanner;

public class User1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Number: ");
		int n = sc.nextInt();
		Calc c1 = new Calc();
		int root = c1.findRoot(n);
		System.out.println("Square Root of given no: " +root);
	}
}
