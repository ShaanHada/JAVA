package First;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;

public class Date {
	public void lastDate(int year, int month) {
		LocalDate lastDay = YearMonth.of(2017,04).atEndOfMonth();
		  System.out.println("Last day of given month: "+
		    lastDay.getDayOfWeek() + "," + lastDay);
	}
	
	
	public static void LocalDateTimeApi() {
		LocalDateTime current = LocalDateTime.now();
		System.out.println("Current Date and time: "+current);
	}
}
