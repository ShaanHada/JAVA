package First;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class Date {
	public int day;
	public String month;
	public int year;
	
//	public static  LocalDate LastDate(String m, int y) {
//		LocalDate initial = LocalDate.of(y, Month.DECEMBER, 12);
//		return LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
//	}
	
	public static void LocalDateTimeApi() {
		LocalDateTime current = LocalDateTime.now();
		System.out.println("Current Date and time: "+current);
	}

}
