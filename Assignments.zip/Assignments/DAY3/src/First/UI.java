package First;

import java.util.Scanner;

public class UI {

	public static void main(String[] args) {
//		System.out.println("Enter Month & Year: ");
//		Scanner sc = new Scanner(System.in);
//		String m = sc.next();
//		int y = sc.nextInt();
		Date d1 = new Date();
//		d1.LastDate( m,y);
//		System.out.println("Last Date: "+d1);
		d1.LocalDateTimeApi();
		
	}

}