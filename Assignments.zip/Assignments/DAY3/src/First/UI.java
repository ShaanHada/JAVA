package First;

import java.util.Scanner;

public class UI {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in)){
		System.out.println("Enter Year: ");
		int year = sc.nextInt();
		System.out.println("Enter Month in digits: ");
		int month = sc.nextInt();
		
		Date d1 = new Date();
		d1.lastDate(year, month);
		Date.LocalDateTimeApi();	//static method should be accessed in  static way
		}
	}

}