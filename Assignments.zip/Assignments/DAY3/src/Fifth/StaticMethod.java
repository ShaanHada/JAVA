package Fifth;

public class StaticMethod {
	private static int empid;
	private static String firstname;
	private static String lastname;	
	private static String city;
	private static String state;
	
	static {
		empid = 101;
		firstname = "Bhuvan";
		lastname = "Bam";
		city = "Pune";
		state = "Maharashtra";
	}

	public static int getEmpid() {
		return empid;
	}

	public static void setEmpid(int empid) {
		StaticMethod.empid = empid;
	}

	public static String getFirstname() {
		return firstname;
	}

	public static void setFirstname(String firstname) {
		StaticMethod.firstname = firstname;
	}

	public static String getLastname() {
		return lastname;
	}

	public static void setLastname(String lastname) {
		StaticMethod.lastname = lastname;
	}

	public static String getCity() {
		return city;
	}

	public static void setCity(String city) {
		StaticMethod.city = city;
	}

	public static String getState() {
		return state;
	}

	public static void setState(String state) {
		StaticMethod.state = state;
	}
	
}
