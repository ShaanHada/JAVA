package Fifth;

public class UI {

	public static void main(String[] args) {
		System.out.println("EmpId: "+StaticMethod.getEmpid());
		System.out.println("FirstName: "+StaticMethod.getFirstname());
		System.out.println("LastName: "+StaticMethod.getLastname());
		System.out.println("City: "+StaticMethod.getCity());
		System.out.println("State: "+StaticMethod.getState());

	}

}
