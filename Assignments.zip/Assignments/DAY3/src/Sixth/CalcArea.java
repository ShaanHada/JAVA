package Sixth;

public class CalcArea {
	
	public static int Area(int h, int b) {
		int area = (h*b)/2;
		return area;
	}

}
