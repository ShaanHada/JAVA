package Sixth;

import java.util.Scanner;

public class UI {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		System.out.println("Enter height and base of traingle: ");
		int height = sc.nextInt();
		int base = sc.nextInt();
		int area = CalcArea.Area(height, base);
		System.out.println("Area of triangle: "+area);
	}
}
