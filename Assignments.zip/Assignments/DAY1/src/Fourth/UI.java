package Fourth;

import java.time.LocalDate;

public class UI {

	public static void main(String[] args) {
		Account a1 = new Account(10001,"Sanjay",LocalDate.of(1995, 12, 12),24);
		System.out.println("First Account: "+a1.toString());
	}
}
