package Fourth;

import java.time.LocalDate;

public class Account {
	private int AccNo;
	private String Name;
	private LocalDate DOB;
	private int Age;
	

	public Account(int accNo, String name, LocalDate dOB, int age) {	//	Parameterised Constructor/////////
		super();
		AccNo = accNo;
		Name = name;
		DOB = dOB;
		Age = age;
	}


	@Override
	public String toString() {
		return " [AccNo=" + AccNo + ", Name=" + Name + ", DOB=" + DOB + ", Age=" + Age + "]";
	}
	
}
