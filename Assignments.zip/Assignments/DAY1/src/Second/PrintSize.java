package Second;

public class PrintSize {
	public static void main(String[] args) {
		System.out.println("Size of int: "+(Integer.SIZE/8) +" bytes");
		System.out.println("Size of int: "+(Float.SIZE/8) +" bytes");
		System.out.println("Size of int: "+(Long.SIZE/8) +" bytes");
		System.out.println("Size of int: "+(Double.SIZE/8) +" bytes");
		System.out.println("Size of int: "+(Character.SIZE/8) +" bytes");
	}

}
